<div class="text-center">
    <img 
        src="images/erro.png" 
        alt="Página não encontrada"
        class="w-100"
    > 
</div>